#include<stdio.h>
#include<graphics.h>
void main()
{
	int gd=DETECT,gm;
	initgraph(&gd,&gm,"..\\bgi");
	int x1=20,y1=20,x2=80,y2=100,x3=120,y3=80,x4=140,y4=120;
	putpixel(x1,y1,RED);
	putpixel(x2,y2,RED);
	putpixel(x3,y3,RED);
	putpixel(x4,y4,RED);
	float t;
	for(t=0.0;t<1.0;t+=.001)
	{
		int x=(1-t)*(1-t)*(1-t)*x1+3*t*(1-t)*(1-t)*x2+3*t*t*(1-t)*x3+t*t*t*x4;
		int y=(1-t)*(1-t)*(1-t)*y1+3*t*(1-t)*(1-t)*y2+3*t*t*(1-t)*y3+t*t*t*y4;
		putpixel(x,y,WHITE);
	}
	delay(5000);
	closegraph();
}
