#include <graphics.h>
#include <stdio.h>
void flood_fill4(int x,int y,int newColor,int oldColor)
{
int c;
c=getpixel(x,y);
if(c==oldColor)
{
//setcolor(newColor);
putpixel (x,y,newColor);
delay(10);
flood_fill4(x+1,y,newColor,oldColor);
flood_fill4(x,y+1,newColor,oldColor);
flood_fill4(x-1,y,newColor,oldColor);
flood_fill4(x,y-1,newColor,oldColor);
}
}
void main()
{
int gd=DETECT,gm;
initgraph(&gd,&gm,"..\\bgi");
int points[]={40,20,70,30,80,50,50,40,20,50,40,20};
drawpoly(6,points);
//rectangle(50,50,100,100);
//flood_fill4(51,51,4,0); // 4(red) - newColor  0(black) - oldColor
          // x y point should be one greater than rectangle border
flood_fill4(50,35,4,0);
delay(1000);
closegraph();
} 

