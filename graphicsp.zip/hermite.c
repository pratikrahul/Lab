#include<bits/stdc++.h>
using namespace std;
int r[1000][1000];
int main(){
	for(int i=0;i<1000;i++){
		for(int j=0;j<1000;j++){
			r[i][j]=0;
		}
	}
	for(double t=0;t<1;t+=0.001){
		double x = 100.0*(2.0*t*t*t-3.0*t*t+1.0)+10.0*(-2.0*t*t*t + 3.0*t*t)
				-300.0*(t*t*t-2.0*t*t*+t)+10.0*(t*t*t-t*t);
		double y = 10.0*(2.0*t*t*t-3.0*t*t+1.0)+100.0*(-2.0*t*t*t + 3.0*t*t)
						-300.0*(t*t*t-2.0*t*t*+t)+10.0*(t*t*t-t*t);
		cout<<x<<" "<<y<<endl;
		r[(int)x][(int)y] = 255;
	}
	FILE *fp = fopen("hermite1.ppm","wb");
	fprintf(fp,"P3\n1000\n1000\n255\n");
	for(int i=0;i<1000;i++){
		for(int j=0;j<1000;j++){
			fprintf(fp,"%d 0 0 ",r[j][i]);
			//cout<<i<<" "<<j<<endl;
		}
		fprintf(fp,"\n");
	}
	fclose(fp);
	return 0;
}

