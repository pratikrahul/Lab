#include<iostream>
#include<graphics.h>
#include<math.h>
using namespace std;
 
int main()
{
	int i,gd=DETECT,gm;
	int points[][2]={{30,65},{60,20},{60,100},{85,50}};
	int pointe[][2]={{55,30},{110,90},{80,70},{120,75}};
	int x1,y1,x2,y2,xmin,xmax,ymin,ymax,xx1,xx2,yy1,yy2,dx,dy;
	float t1,t2,p[4],q[4],temp;
	
	xmin=40;
	ymin=40;
	xmax=100;
	ymax=80;
	
	initgraph(&gd,&gm,NULL);
	rectangle(xmin,ymin,xmax,ymax);

	for(int i=0;i<4;i++)
	{	
		x1=points[i][0];
		y1=points[i][1];
		x2=pointe[i][0];
		y2=pointe[i][1];
		dx=x2-x1;
		dy=y2-y1;
		
		p[0]=-dx;
		p[1]=dx;
		p[2]=-dy;
		p[3]=dy;
		
		q[0]=x1-xmin;
		q[1]=xmax-x1;
		q[2]=y1-ymin;
		q[3]=ymax-y1;
		
		int flag=0;
		for(i=0;i<4;i++)
		{
			if(p[i]==0)
			{
				cout<<"line is parallel to one of the clipping boundary";
				if(q[i]>=0)
				{
					if(i<2)
					{
						if(y1<ymin)
						{
							y1=ymin;
						}
					
						if(y2>ymax)
						{
							y2=ymax;
						}
					
						line(x1,y1,x2,y2);
					}
					
					if(i>1)
					{
						if(x1<xmin)
						{
							x1=xmin;
						}
						
						if(x2>xmax)
						{
							x2=xmax;
						}
						
						line(x1,y1,x2,y2);
					}
				}
				flag=1;
			}
		}
		
		if(flag==0)
		{	
			t1=0;
			t2=1;
			
			for(i=0;i<4;i++)
			{
				temp=q[i]/p[i];
				
				if(p[i]<0)
				{
					if(t1<=temp)
						t1=temp;
				}
				else
				{
					if(t2>temp)
						t2=temp;
				}
			}
			
			if(t1<t2)
			{
				xx1 = x1 + t1 * p[1];
				xx2 = x1 + t2 * p[1];
				yy1 = y1 + t1 * p[3];
				yy2 = y1 + t2 * p[3];
				line(xx1,yy1,xx2,yy2);
			}
		}
	}
	
	delay(5000);
	closegraph();
return 0;
}
