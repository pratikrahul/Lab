#include<stdio.h>
#include<graphics.h>
void draw(int xc,int yc,int x,int y)
{
	putpixel(xc+x,yc+y,WHITE);
	putpixel(xc+x,yc-y,WHITE);
	putpixel(xc-x,yc+y,WHITE);
	putpixel(xc-x,yc-y,WHITE);
	putpixel(xc+y,yc+x,WHITE);
	putpixel(xc+y,yc-x,WHITE);
	putpixel(xc-y,yc+x,WHITE);
	putpixel(xc-y,yc-x,WHITE);
}
void circle(int xc,int yc,int r)
{
	int x=0;
	int y=r;
	int d=1-r;
	draw(xc,yc,x,y);
	while(y>=x)
	{

		x++;
		if(d<0) d=d+2*x+1;
		else
		{
			y--;
			d=d+2*x+1-2*y;
		}
	draw(xc,yc,x,y);
	}
}
int main()
{
	int gd=DETECT,gm;
	int xc=100;
	int yc=100;
	int r=25;
	initgraph(&gd,&gm,NULL);
	circle(xc,yc,r);
	delay(1000);
	closegraph();
	return 0;
}

